require "govuk_template/version"
require "govuk_template/engine"

module GovukTemplate
end
