module GovukTemplate
  VERSION = "0.15.1"
end
